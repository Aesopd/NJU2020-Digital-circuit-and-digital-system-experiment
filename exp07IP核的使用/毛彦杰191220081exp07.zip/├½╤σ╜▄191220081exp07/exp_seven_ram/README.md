# 数字电路第七次实验

## exp_seven_ram.v为总工程文件，调用两个ram
#### exp_seven_ram.sof为最后烧入实验板上的文件
#### exp_seven_ram.vt是对整个工程模拟的激励代码

## ram1.v为自己设计代码实现的RAM1
#### mem1.txt为初始化RAM1使用的文本文件

## ram2.v为利用IP核生成的RAM2
#### ram2.qip为相应的qip文件
#### ram2.mif为初始化RAM2的文件
