# 数字电路第6次实验
## exp_six_register为6.3.1算数移位和逻辑移位寄存器
## exp_six_random为6.3.2利用移位寄存器实现随机数发生器
